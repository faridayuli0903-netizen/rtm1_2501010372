# Tugas 1: Akuisisi Data Nyata (BIFP-243)
- **Nama:** Yuliana Farida
- **NIM:** 2501010372
- **Kelas:** 3 / F — Program Studi Informatika, INSTIKI

## 1. Sumber Data
- **Nama Sumber:** Wikipedia Bahasa Indonesia (MediaWiki Action API)
- **URL:** https://id.wikipedia.org/w/api.php
- **Penerbit:** Wikimedia Foundation
- **Alasan Pemilihan:** Menyediakan daftar terstruktur objek pariwisata, warisan budaya, pura, seni tari, dan kuliner di Bali.

## 2. Tanggal dan Jam Akses
- **Waktu Akses:** 16 November 2026, pukul 00:40:17 WITA

## 3. Metode Akuisisi
- **Teknik:** Pengambilan data melalui MediaWiki Action API menggunakan pustaka `requests` Python.
- **Endpoint:** `https://id.wikipedia.org/w/api.php`
- **Parameter Query:** `action=query`, `list=categorymembers` untuk kategori `Pariwisata_di_Bali`, `Budaya_Bali`, `Pura_di_Bali`, `Tarian_Bali`, dan `Masakan_Bali`.

## 4. Batasan Etika
- **Ketentuan & Lisensi:** Berlisensi CC BY-SA 4.0 dan mematuhi Wikimedia API Etiquette.
- **Jeda & Rate Limit:** Diberikan jeda `time.sleep(1.5)` antar-request dan batas `timeout=30` detik.
- **Data yang Tidak Diambil:** Tidak mengambil data personal individu maupun informasi sensitif apa pun.

## 5. Penjelasan Kolom Dataset
1. `page_id`: Nomor identifikasi unik halaman pada basis data Wikipedia.
2. `title`: Judul artikel objek wisata, budaya, pura, tarian, atau kuliner Bali.
3. `category`: Kategori tematik data (`Pariwisata di Bali`, `Budaya Bali`, `Pura di Bali`, `Tarian Bali`, `Masakan Bali`).
4. `namespace`: Kode ruang nama halaman Wikipedia (`0` untuk artikel utama).
5. `source_url`: Tautan permanen menuju halaman artikel sumber.

## 6. Cara Menjalankan Ulang Notebook
1. Pastikan Python 3 beserta pustaka `requests` dan `pandas` sudah terinstal (`pip install requests pandas`).
2. Buka berkas `notebooks/akuisisi_wikipedia.ipynb`.
3. Pilih menu **Run All** untuk menjalankan seluruh sel dari awal hingga akhir.
4. Berkas dataset mentah dan dokumentasi akan otomatis diperbarui di folder masing-masing.
